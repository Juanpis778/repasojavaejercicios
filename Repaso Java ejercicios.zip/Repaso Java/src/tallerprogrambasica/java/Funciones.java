package tallerprogrambasica;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Juanito
 */
public class Funciones {

    public static void operaciones() {
        Scanner escaner = new Scanner(System.in);
        System.out.println("Digite el primer número entero: ");
        int num1 = escaner.nextInt();
        System.out.println("Digite el segundo número entero: ");
        int num2 = escaner.nextInt();
        int sum = num1 + num2;
        int rest = num1 - num2;
        int resid;

        if (num1 > num2) {
            resid = num1 % num2;
        } else {
            resid = num2 % num1;
        }
        System.out.println("El Resultado de la Suma es: " + sum);
        System.out.println("El Resultado de la resta es: " + rest);
        System.out.println("El Residuo es: " + resid);
    }

    public static void reinoAnimal() {
        Scanner entrada = new Scanner(System.in);
        String bacteria, algas, hongo, flores, insecto;
        String serVivo;
        System.out.println("Escriba una de las siguientes opciones: ");
        System.out.println("bacteria - algas - hongo - flores - insecto ");
        serVivo = entrada.nextLine();

        if (serVivo.equalsIgnoreCase("bacteria")) {
            System.out.println("El Ser Vivo " + serVivo + ", Pertenece al Reino Monera");
        } else {
            if (serVivo.equalsIgnoreCase("algas")) {
                System.out.println("El Ser Vivo " + serVivo + ", Pertenece al Reino Protista");
            } else {
                if (serVivo.equalsIgnoreCase("hongo")) {
                    System.out.println("El Ser Vivo " + serVivo + ", Pertenece al Reino Fungi");
                } else {
                    if (serVivo.equalsIgnoreCase("flores")) {
                        System.out.println("El Ser Vivo " + serVivo + ", Pertenece al Reino Vegetal");
                    } else if (serVivo.equalsIgnoreCase("insecto")) {
                        System.out.println("El Ser Vivo " + serVivo + ", Pertenece al Reino Animal");
                    }
                }
            }
        }
    }
    
    public static void notaMusical() {
        int num;
        
        num = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite un número del 1 al 7"));
        
        switch (num){
            case 1: JOptionPane.showMessageDialog(null, "El número corresponde a la nota musical :"+ "DO");
            break;
            case 2: JOptionPane.showMessageDialog(null, "El número corresponde a la nota musical :"+ "RE");
            break;
            case 3: JOptionPane.showMessageDialog(null, "El número corresponde a la nota musical :"+ "MI");
            break;
            case 4: JOptionPane.showMessageDialog(null, "El número corresponde a la nota musical :"+ "FA");
            break;
            case 5: JOptionPane.showMessageDialog(null, "El número corresponde a la nota musical :"+ "SOL");
            break;
            case 6: JOptionPane.showMessageDialog(null, "El número corresponde a la nota musical :"+ "LA");
            break;
            case 7: JOptionPane.showMessageDialog(null, "El número corresponde a la nota musical :"+ "SI");
            break;
            default: JOptionPane.showMessageDialog(null, "El número ingresado corresponde no se encuenta dentro del 1 y el 7");
            break;
        }
    }
    
    public static void conteo(){
        int num;
        
        num = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un número"));
        
        for (int i =0; i<= num; i++){
             JOptionPane.showMessageDialog(null, i);
 
        }
  
    }
    
    public static void conteo2(){
        int num;
        
        num = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un número"));
        
        for (int i =0; i<= num; i= i+3){
             JOptionPane.showMessageDialog(null, i);

        }
  
    }
    
    public static void numPar(){
        int n;
        
        n = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese su número"));
        
        if(n%2==0){
            JOptionPane.showMessageDialog(null,"El número Ingresado es Par");
        }else {
            JOptionPane.showMessageDialog(null, "El número ingresado es Impar");
        }

    }
    
    public static void fibonacci(){
        
        int num;
        int a=0, b=1, c=0;
        
        
        num = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese su número"));
        
        while(a<num){
            a=b+c;
            b=c;
            c=a;
            
            JOptionPane.showMessageDialog(null, a);
        }
    }
    
    public static void adivinar(){
        
        final int numAdivinar = 7;
        int nEntrada;
        final int intentos=3;
        int nActualIntentos = 0;
        boolean falloTdsintentos = false;
        boolean acerto=true;
        
        
        while(nActualIntentos <= intentos){
            
            if(nActualIntentos >= intentos){
                falloTdsintentos = true;
                JOptionPane.showMessageDialog(null, "Clave Bloqueada");
                break;
            }
            
            nEntrada = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese su número"));
            nActualIntentos++;
        
             if (nEntrada == numAdivinar){
                 JOptionPane.showMessageDialog(null, "Acceso permitido");
             }else{
                 JOptionPane.showMessageDialog(null, "Acceso denegado");
                 continue;
             }
        
            if(acerto){
                break;
            }
        }
      
    }
    
    public static void creatividad(){
        
        
        int entrada;
        
        entrada = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el número "));
       
       
        
        
        if(entrada <0){
            JOptionPane.showMessageDialog(null, "El número dado es Negativo.");
            
        }else{
            JOptionPane.showMessageDialog(null, "El número dado es positivo.");

        }
      
    }
    
    
}